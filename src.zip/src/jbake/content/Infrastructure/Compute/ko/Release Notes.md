title=About
date=2013-09-24
type=page
status=published
summary=TCcomputeRelease
big=TCInfra
~~~~~~


<h2 id="toast-cloud-release-notes">TOAST Cloud &gt; Release Notes</h2>
<h3 id="20170824">2017.08.24</h3>
<h4 id="_1">기능 개선/변경</h4>
<h5 id="tc-console">TC Console</h5>

* Infrastructure 요금 테이블 변경
	* Infrastructure 요금제에 Basic 과 Storage Optimized 요금제가 추가 되었습니다.
	* 저사양 Basic 과 High IOPS SSD를 제공하는 Storage Optimized를 제공 받으실 수 있습니다.
	* 자세한 사양은 <a href="https://cloud.toast.com/pricing" target=_blank">TOASTCloud Pricing 페이지</a> 및 요금계산기서 확인 할 수 있습니다.
* Billing Viewer 권한 추가
	* Project의 Member 권한중 사용량 페이지를 조회할 수 있는
	* Billing Viewer는 Project 내의 모든 행위는 제한 되며,


버그 수정
TC Conosole

* 공지사항 버그 수정
	* 공지사항 ALL, FAQ 카테고리 글자가 나타나지 않는 현상이 수정되었습니다.


<h4 id="_2">버그 수정</h4>
<h5 id="tc-console_2">TC Console</h5>

<h3 id="201622">2017.06.22</h3>
<h4 id="_3">기능 개선/변경</h4>
<h5 id="tc-console_3">TC Console</h5>



<h3 id="20170525">2017.05.25</h3>
<h4 id="_4">기능 개선/변경</h4>
<h5 id="tc-console_4">TC Console</h5>

<h4 id="_5">버그 수정</h4>
<h5 id="tc-console_4">TC Console</h5>


<h3 id="20170420">2017.04.20</h3>
<h4 id="_6">기능 개선/변경</h4>
<h5 id="tc-console_5">TC Console</h5>


<h4 id="_7">버그 수정</h4>
<h5 id="tc-console_6">TC Console</h5>

<h3 id="20170323">2017.03.23</h3>
<h4 id="_8">기능 개선/변경</h4>
<h5 id="tc-console_7">TC Console</h5>

<h4 id="_9">버그 수정</h4>
<h5 id="tc-console_8">TC Console</h5>


<h3 id="20170223">2017.02.23</h3>
<h4 id="_10">기능 개선/변경</h4>
<h5 id="tc-console_9">TC Console</h5>
