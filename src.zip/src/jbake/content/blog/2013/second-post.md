title=Second Post
date=2013-08-25
type=post
tags=blog
status=published
~~~~~~

### 안녕세요!


* [http://example.org](http://example.org)

~~~
{ 
        "title" : "{제목}",
        "body" : "{본문 내용}",
        "sendNo" : "{발신번호}",
        "recipientLsit":[{
             "recipientNo":"{수신번호}",
             "templateParameter":{ }
         }],
        "userId": ""
}
~~~

* 1 단계
    * 2 단계
        * 3 단계


자바 'main' 메소드입니다.
    
    public static void main(String args[]){
        System.out.println("Hello World!");
    }


