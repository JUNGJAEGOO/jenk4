title=About
date=2013-09-24
type=page
status=published
summary=Image
big=TCcontents
~~~~~~

##TOAST Cloud Overview##

TOAST Cloude란 NHN 엔터테인먼트에서 제공하는 클라우드 서비스입니다.

-누구나 쉽게 개발할 수 있는 서비스를 제공하는 퍼블릭 클라우드
-개발에만 전녕할 수 있도록 인프라에서 플랫폼까지 다양한 솔루션 제공
-웹 브라우 상에서 인프라에서 플랫폼까지 모두 관리할 수 있는 콘솔 제공
-합리적 비용으로 사업화에 기여


#서비스 구성#
인프라, 개발, 테스트, 운영과 기술지원, 사업화에 필요한 다양한 서비스를 제공합니다.

|:서비스:|:설명:|
|-------|-----|
|:Infrastructure Service:|:Open Stack 기반 On-Demand 인프라 서비스:|
|:Contents Service:|:이미지 저장 및 배포 플랫폼:|
|:Analystics Service:|:앱 데이터 분석 운영 플랫폼 지원:|
|:Game Service:|:게임 개발 지원:|
|:Notification Service:|:모바일 푸쉬 및 sms 플랫:|
|:Security Service:|:보안 플랫폼:|
|:Common Service:|:개발/테스트/서비스에 필요한 공통 도구:|







~~~
    이것은 코드 블럭
    입니다.
~~~



>> 내가 우습냐
    만만해 보이냐
