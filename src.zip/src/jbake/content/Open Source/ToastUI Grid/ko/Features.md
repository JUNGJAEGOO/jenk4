title=About
date=2013-09-24
type=page
status=published
big=TCOpensource
summary=ToastUIGridFeatures
~~~~~~

## Open Source > ToastUI Grid > Features

# Features

- [Input types](https://github.com/nhnent/tui.grid/wiki/Input-types)
- [Multi column header](https://github.com/nhnent/tui.grid/wiki/Multi-column-header)
- [Relation between columns](https://github.com/nhnent/tui.grid/wiki/Relation-between-columns)
- [Binding to remote data](https://github.com/nhnent/tui.grid/wiki/Binding-to-remote-data)
- [Applying Themes](https://github.com/nhnent/tui.grid/wiki/Applying-Themes)
- [Using DatePicker in Grid](https://github.com/nhnent/tui.grid/wiki/Using-DatePicker-in-Grid)
