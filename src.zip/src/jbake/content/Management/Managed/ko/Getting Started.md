title=About
date=2013-09-24
type=page
status=published
big=Management
summary=ManagementGetting
~~~~~~
## Management > Managed > Getting Started

## 상품 이용 
Console 에 접속하여 Managed 를 선택합니다. 

매니지드 상품을 선택(Managed Basic / Managed Pro) 하여 상품 이용 신청을 합니다. 
![[그림 1] Managed 상품](http://static.toastoven.net/prod_managed/managed_1.jpg)

instance 명을 입력합니다. 
instance 명은 n 개를 입력할 수 있으며, 쉼표(,) 로 구분하여 입력합니다. 
![[그림 2] Managed 상품 이용 신청](http://static.toastoven.net/prod_managed/managed_2.jpg)


Managed 신청 내역은 Managed 상품 화면에서 확인이 가능합니다. 
![[그림 5] 이용 현황](http://static.toastoven.net/prod_managed/managed_5.jpg)

## 상품 종료 
Console 에 접속하여 Managed 를 선택합니다.
이용 중인 Managed 상품의 이용 현황을 확인 하여 종료하고자 하는 상품의 종료 신청을 합니다. 

![[그림 6] Managed 상품 이용 종료 신청](http://static.toastoven.net/prod_managed/managed_6.jpg)








