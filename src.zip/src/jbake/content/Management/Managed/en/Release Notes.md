title=About
date=2013-09-24
type=page
status=published
big=
summary=
~~~~~~
## Management > Managed > Release Notes

### 2017.06.22
#### 신규 상품 출시
* Managed 서비스는 전문 지식을 겸비한 전담 엔지니어가 구축부터 운영/백업까지 서비스를 안정적으로 관리해 드리는 서비스입니다.
* IT 전문 인력이 없어도 장애 발생 시 즉각적인 조치를 취할 수 있고 사용 중인 리소스를 안정적인 상태로 유지할 수 있습니다.
