jbake-example-project-freemarker
========================

Example project structure for JBake that uses Freemarker templates and Bootstrap.